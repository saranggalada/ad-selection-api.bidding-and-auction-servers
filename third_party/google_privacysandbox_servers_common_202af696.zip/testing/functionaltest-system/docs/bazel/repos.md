<!-- Generated with Stardoc: http://skydoc.bazel.build -->

Expose external repo dependencies for this WORKSPACE.

<a id="repositories"></a>

## repositories

<pre>
repositories()
</pre>

Register bazel repositories.



<a id="test_repositories"></a>

## test_repositories

<pre>
test_repositories()
</pre>

Retrieve example protobuf files used for tests



