# Building

## Building Proxy

Use the existing shell script to build proxy:

```shell
scripts/build-proxy
```

## Run proxy

Extract and run the proxy binary for your Linux distribution:

```shell
unzip dist/aws/<proxy for your Linux distribution>
./proxy --helpfull
./proxy --stderrthreshold=0
```
